#!/usr/bin/python

import os

print "Running feature_selection.py"
e = os.system("python ./core_feature_selection.py >& prg_log");
