#!/bin/csh

echo "kocos.pl integration testing has no error-handling tests yet"
echo " "
